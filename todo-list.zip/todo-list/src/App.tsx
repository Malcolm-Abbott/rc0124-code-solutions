import { Todos } from './Pages/Todos';

function App() {
  return (
    <>
      <Todos />
    </>
  );
}

export default App;
